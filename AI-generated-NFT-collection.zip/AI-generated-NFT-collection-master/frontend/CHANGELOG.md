# Changelog

All notable changes to this project will be documented in this file. See [standard-version](https://github.com/conventional-changelog/standard-version) for commit guidelines.

## [1.1.0](https://gitlab.com/starton/librairies/starton-ui-nextjs/-/compare/1.0.4...1.1.0) (2023-03-27)


### ✨ Features

* update deps, change code base, add code quality ([e560dd6](https://gitlab.com/starton/librairies/starton-ui-nextjs/-/commit/e560dd62c9cc32d2454d935d3047e3f7fa2a4b2a))
