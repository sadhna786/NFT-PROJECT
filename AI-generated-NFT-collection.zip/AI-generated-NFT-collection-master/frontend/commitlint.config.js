/*
| Developed by Starton
| Filename : commitlint.config.js
| Author : Philippe DESPLATS (philippe@starton.com)
*/

// eslint-disable-next-line no-undef
module.exports = {
	extends: ['@commitlint/config-conventional'],
}
