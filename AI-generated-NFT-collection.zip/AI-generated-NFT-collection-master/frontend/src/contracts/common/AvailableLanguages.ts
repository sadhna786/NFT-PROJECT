/*
| Developed by Dirupt
| Filename : AvailableLanguages.ts
| Author : DESPLATS Philippe (philippe@di-rupt.com)
*/

export enum AvailableLanguages {
	// eslint-disable-next-line no-unused-vars
	FR = 'fr',
	// eslint-disable-next-line no-unused-vars
	EN = 'en',
}
