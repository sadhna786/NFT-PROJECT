/*
| Developed by Starton
| Filename : StartonFooterSocialButton
| Author : Calixte DE TOURRIS (calixte@starton.com)
*/

import React from 'react'

/*
|--------------------------------------------------------------------------
| Contracts
|--------------------------------------------------------------------------
*/
export interface StartonFooterSocialButtonProps {}

/*
|--------------------------------------------------------------------------
| Component
|--------------------------------------------------------------------------
*/
export const StartonFooterSocialButton: React.FC<StartonFooterSocialButtonProps> = () => {
	return <React.Fragment></React.Fragment>
}
