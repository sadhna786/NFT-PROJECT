/*
| Developed by Starton
| Filename : index.ts
| Author : Calixte DE TOURRIS (calixte@starton.com)
*/

export * from './StartonButton'
